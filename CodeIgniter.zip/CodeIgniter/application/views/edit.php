<!DOCTYPE html>
<html>
<head>
	<title>Crud Application -Update User</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css';?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/stylesheet.css';?>">
</head>
<body>
<div class="navbar navbar-dark bg-dark">
	<div class="container">
		<a href="#" class="navbar-brand">CRUD APPLICATION</a>
	</div>
</div>
<div class="container" style="padding-top: 10px">
	<h3>Update User</h3>
	<hr>
	<form method="post" name="updateUser" action="<?php base_url().'index.php/User/edit/'.$user['sl_num'];?>">
	    <div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label>Name</label>
					<input type="text" name="name" value="<?php echo set_value('name',$user['name']);?>" placeholder="Your Name !!" class="form-control">
					<?php echo form_error('name');?>
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="email" name="email" value="<?php echo set_value('email',$user['email']);?>" placeholder="Your Email ID !!"class="form-control">
					<?php echo form_error('email');?>
				</div>
				<div class="form-group">
					<label>Mobile Number</label>
					<input type="tel" name="mobile_number" value="<?php echo set_value('mobile_number',$user['mobile_number']);?>" placeholder="Your Number without +91/0" class="form-control">
					<?php echo form_error('mobile_number');?>
				</div>
				<div class="form-group">
					<label>Date of Birth</label>
					<input type="date" name="dob" value="<?php echo set_value('dob',$user['dob']);?>" class="form-control">
					<?php echo form_error('dob');?>
				</div>
				<div class="form-group">
					<label>Pin Code</label>
					<input type="number" name="pin_code" value="<?php echo set_value('pin_code',$user['pin_code']);?>" placeholder="6 Digit Zip code" class="form-control">
					<?php echo form_error('pin_code');?>
				</div>
				<div class="form-group">
					<button class="btn btn-primary">Update</button>
					<a href="<?php echo base_url().'index.php/user/index';?>" class="btn-secondary btn">Cancel</a>
				</div>
			</div>
	    </div>
	 </form>	
</div>
</body>
</html>