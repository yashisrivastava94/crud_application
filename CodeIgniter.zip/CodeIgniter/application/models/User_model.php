<?php
class User_model extends CI_model{
	function create ($formArray){
		$this->db->insert('Users',$formArray);  //insert into Users (name,email,number) values (*,*,*);
	}

	function all(){
		return $users = $this->db->get('Users')->result_array();  //Select * from users;
	}

	function getUser ($ID){
		$this->db->where('sl_num',$ID);
		return $user = $this->db->get('Users')->row_array();  // select * from users where sl_num=*;
	}

	function updateUser($ID,$formArray) {

		$this->db->where('sl_num',$ID);
		$this->db->update('Users',$formArray);   //Update users set name=*, eamil=*.. where sl_num=*;

	}

	function deleteUser($ID) {

		$this->db->where('sl_num',$ID);
		$this->db->delete('Users');   //delete from Users where sl_num=*;

	}
}
?> 